import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Alert } from 'react-native';
import { commonStyles, colors } from '../styles/commonStyles';
import Icon from './Icon';
import { TradeService } from '../services/TradeService';

interface MT5ConnectionProps {
  isConnected: boolean;
  onConnectionChange: (connected: boolean) => void;
}

export default function MT5Connection({
  isConnected,
  onConnectionChange,
}: MT5ConnectionProps) {
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    console.log('Attempting to connect to MT5...');
    setIsConnecting(true);
    
    try {
      // Simulate connection attempt
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // For demo purposes, we'll simulate a successful connection
      const connected = await TradeService.connectToMT5();
      onConnectionChange(connected);
      
      if (connected) {
        Alert.alert(
          'Success',
          'Successfully connected to MetaTrader 5',
          [{ text: 'OK' }]
        );
      } else {
        Alert.alert(
          'Connection Failed',
          'Unable to connect to MetaTrader 5. Please check your settings.',
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      console.error('Connection error:', error);
      Alert.alert(
        'Error',
        'An error occurred while connecting to MT5',
        [{ text: 'OK' }]
      );
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    console.log('Disconnecting from MT5...');
    try {
      await TradeService.disconnectFromMT5();
      onConnectionChange(false);
      Alert.alert(
        'Disconnected',
        'Disconnected from MetaTrader 5',
        [{ text: 'OK' }]
      );
    } catch (error) {
      console.error('Disconnect error:', error);
    }
  };

  return (
    <View style={commonStyles.card}>
      <View style={commonStyles.row}>
        <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
          <View
            style={{
              width: 12,
              height: 12,
              borderRadius: 6,
              backgroundColor: isConnected ? colors.success : colors.danger,
              marginRight: 12,
            }}
          />
          <View>
            <Text style={[commonStyles.text, { fontWeight: '600' }]}>
              MetaTrader 5
            </Text>
            <Text style={commonStyles.textSecondary}>
              {isConnected ? 'Connected' : 'Disconnected'}
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={{
            backgroundColor: isConnected ? colors.danger : colors.success,
            paddingHorizontal: 16,
            paddingVertical: 8,
            borderRadius: 6,
            opacity: isConnecting ? 0.6 : 1,
          }}
          onPress={isConnected ? handleDisconnect : handleConnect}
          disabled={isConnecting}
        >
          <Text
            style={[
              commonStyles.text,
              { color: colors.background, fontWeight: '600' },
            ]}
          >
            {isConnecting
              ? 'Connecting...'
              : isConnected
              ? 'Disconnect'
              : 'Connect'}
          </Text>
        </TouchableOpacity>
      </View>

      {isConnected && (
        <View style={{ marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: colors.border }}>
          <Text style={commonStyles.textSecondary}>
            ✓ Real-time trade monitoring active
          </Text>
          <Text style={commonStyles.textSecondary}>
            ✓ Automatic trade logging enabled
          </Text>
        </View>
      )}
    </View>
  );
}