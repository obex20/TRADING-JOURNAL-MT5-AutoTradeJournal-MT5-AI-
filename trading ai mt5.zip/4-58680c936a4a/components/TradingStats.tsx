import React from 'react';
import { View, Text } from 'react-native';
import { commonStyles, colors } from '../styles/commonStyles';
import Icon from './Icon';

interface TradingStatsProps {
  stats: {
    totalTrades: number;
    winRate: number;
    totalProfit: number;
    averageProfit: number;
  };
}

export default function TradingStats({ stats }: TradingStatsProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  const statItems = [
    {
      label: 'Total Trades',
      value: stats.totalTrades.toString(),
      icon: 'bar-chart-outline',
      color: colors.primary,
    },
    {
      label: 'Win Rate',
      value: formatPercentage(stats.winRate),
      icon: 'trending-up-outline',
      color: stats.winRate >= 50 ? colors.success : colors.danger,
    },
    {
      label: 'Total P&L',
      value: formatCurrency(stats.totalProfit),
      icon: 'wallet-outline',
      color: stats.totalProfit >= 0 ? colors.success : colors.danger,
    },
    {
      label: 'Avg P&L',
      value: formatCurrency(stats.averageProfit),
      icon: 'analytics-outline',
      color: stats.averageProfit >= 0 ? colors.success : colors.danger,
    },
  ];

  return (
    <View>
      <Text style={commonStyles.subtitle}>Trading Statistics</Text>
      <View style={commonStyles.card}>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {statItems.map((item, index) => (
            <View
              key={index}
              style={{
                width: '50%',
                padding: 8,
                alignItems: 'center',
              }}
            >
              <View
                style={{
                  backgroundColor: `${item.color}20`,
                  borderRadius: 20,
                  padding: 8,
                  marginBottom: 8,
                }}
              >
                <Icon
                  name={item.icon as any}
                  size={24}
                  style={{ color: item.color }}
                />
              </View>
              <Text
                style={[
                  commonStyles.text,
                  { fontWeight: '600', color: item.color, textAlign: 'center' },
                ]}
              >
                {item.value}
              </Text>
              <Text style={[commonStyles.textSecondary, { textAlign: 'center' }]}>
                {item.label}
              </Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}