import React from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { commonStyles, colors } from '../styles/commonStyles';
import Icon from './Icon';
import { router } from 'expo-router';

interface Trade {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  entryPrice: number;
  exitPrice?: number;
  volume: number;
  profit?: number;
  timestamp: string;
  status: 'OPEN' | 'CLOSED';
  notes?: string;
}

interface TradeListProps {
  trades: Trade[];
  onTradeUpdate: () => void;
}

export default function TradeList({ trades, onTradeUpdate }: TradeListProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleTradePress = (trade: Trade) => {
    console.log('Trade pressed:', trade.id);
    router.push(`/trade-details/${trade.id}`);
  };

  const recentTrades = trades.slice(0, 5);

  return (
    <View>
      <View style={commonStyles.row}>
        <Text style={commonStyles.subtitle}>Recent Trades</Text>
        <TouchableOpacity onPress={() => router.push('/all-trades')}>
          <Text style={[commonStyles.textSecondary, { color: colors.primary }]}>
            View All
          </Text>
        </TouchableOpacity>
      </View>

      {recentTrades.length === 0 ? (
        <View style={[commonStyles.card, { alignItems: 'center', padding: 32 }]}>
          <Icon
            name="bar-chart-outline"
            size={48}
            style={{ color: colors.textSecondary, marginBottom: 16 }}
          />
          <Text style={[commonStyles.text, { textAlign: 'center' }]}>
            No trades yet
          </Text>
          <Text style={[commonStyles.textSecondary, { textAlign: 'center' }]}>
            Connect to MT5 or add trades manually
          </Text>
        </View>
      ) : (
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            {recentTrades.map((trade) => (
              <TouchableOpacity
                key={trade.id}
                style={[
                  commonStyles.card,
                  {
                    width: 280,
                    borderLeftWidth: 4,
                    borderLeftColor:
                      trade.status === 'OPEN'
                        ? colors.warning
                        : trade.profit && trade.profit > 0
                        ? colors.success
                        : colors.danger,
                  },
                ]}
                onPress={() => handleTradePress(trade)}
              >
                <View style={commonStyles.row}>
                  <View>
                    <Text style={[commonStyles.text, { fontWeight: '600' }]}>
                      {trade.symbol}
                    </Text>
                    <Text style={commonStyles.textSecondary}>
                      {trade.type} • {trade.volume} lots
                    </Text>
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <Text
                      style={[
                        commonStyles.text,
                        {
                          fontWeight: '600',
                          color:
                            trade.status === 'OPEN'
                              ? colors.warning
                              : trade.profit && trade.profit > 0
                              ? colors.success
                              : colors.danger,
                        },
                      ]}
                    >
                      {trade.status === 'OPEN'
                        ? 'OPEN'
                        : formatCurrency(trade.profit || 0)}
                    </Text>
                    <Text style={commonStyles.textSecondary}>
                      {formatDate(trade.timestamp)}
                    </Text>
                  </View>
                </View>

                <View style={{ marginTop: 12 }}>
                  <View style={commonStyles.row}>
                    <Text style={commonStyles.textSecondary}>Entry:</Text>
                    <Text style={commonStyles.text}>
                      {formatCurrency(trade.entryPrice)}
                    </Text>
                  </View>
                  {trade.exitPrice && (
                    <View style={commonStyles.row}>
                      <Text style={commonStyles.textSecondary}>Exit:</Text>
                      <Text style={commonStyles.text}>
                        {formatCurrency(trade.exitPrice)}
                      </Text>
                    </View>
                  )}
                </View>

                {trade.notes && (
                  <View style={{ marginTop: 8 }}>
                    <Text
                      style={[
                        commonStyles.textSecondary,
                        { fontStyle: 'italic' },
                      ]}
                      numberOfLines={2}
                    >
                      "{trade.notes}"
                    </Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      )}
    </View>
  );
}