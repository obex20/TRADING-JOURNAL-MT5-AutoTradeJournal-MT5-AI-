import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Trade {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  entryPrice: number;
  exitPrice?: number;
  volume: number;
  profit?: number;
  timestamp: string;
  status: 'OPEN' | 'CLOSED';
  notes?: string;
  stopLoss?: number;
  takeProfit?: number;
  commission?: number;
  swap?: number;
}

export interface TradingStats {
  totalTrades: number;
  winRate: number;
  totalProfit: number;
  averageProfit: number;
  winningTrades: number;
  losingTrades: number;
  largestWin: number;
  largestLoss: number;
}

class TradeServiceClass {
  private readonly TRADES_KEY = 'trading_journal_trades';
  private readonly CONNECTION_KEY = 'mt5_connection_status';
  private isConnected = false;

  // MT5 Connection Methods
  async connectToMT5(): Promise<boolean> {
    console.log('TradeService: Attempting MT5 connection...');
    
    try {
      // Simulate MT5 connection process
      // In a real implementation, this would connect to MT5 API
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // For demo purposes, simulate successful connection
      this.isConnected = true;
      await AsyncStorage.setItem(this.CONNECTION_KEY, 'true');
      
      // Start monitoring trades (simulation)
      this.startTradeMonitoring();
      
      console.log('TradeService: MT5 connection successful');
      return true;
    } catch (error) {
      console.error('TradeService: MT5 connection failed:', error);
      return false;
    }
  }

  async disconnectFromMT5(): Promise<void> {
    console.log('TradeService: Disconnecting from MT5...');
    this.isConnected = false;
    await AsyncStorage.setItem(this.CONNECTION_KEY, 'false');
    this.stopTradeMonitoring();
  }

  async checkConnection(): Promise<boolean> {
    try {
      const status = await AsyncStorage.getItem(this.CONNECTION_KEY);
      this.isConnected = status === 'true';
      return this.isConnected;
    } catch (error) {
      console.error('TradeService: Error checking connection:', error);
      return false;
    }
  }

  // Trade Monitoring (Simulation)
  private monitoringInterval?: NodeJS.Timeout;

  private startTradeMonitoring(): void {
    console.log('TradeService: Starting trade monitoring...');
    
    // Simulate periodic trade updates
    this.monitoringInterval = setInterval(async () => {
      if (this.isConnected) {
        await this.simulateNewTrade();
      }
    }, 30000); // Check every 30 seconds
  }

  private stopTradeMonitoring(): void {
    console.log('TradeService: Stopping trade monitoring...');
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = undefined;
    }
  }

  private async simulateNewTrade(): Promise<void> {
    // Simulate random trade generation for demo
    const symbols = ['EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'USDCAD'];
    const types: ('BUY' | 'SELL')[] = ['BUY', 'SELL'];
    
    const randomSymbol = symbols[Math.floor(Math.random() * symbols.length)];
    const randomType = types[Math.floor(Math.random() * types.length)];
    const randomPrice = 1.0000 + Math.random() * 0.5;
    const randomVolume = Math.round((Math.random() * 2 + 0.1) * 100) / 100;

    const newTrade: Trade = {
      id: Date.now().toString(),
      symbol: randomSymbol,
      type: randomType,
      entryPrice: randomPrice,
      volume: randomVolume,
      timestamp: new Date().toISOString(),
      status: 'OPEN',
      notes: 'Auto-imported from MT5',
    };

    console.log('TradeService: Simulated new trade:', newTrade);
    await this.saveTrade(newTrade);
  }

  // Trade Data Management
  async getAllTrades(): Promise<Trade[]> {
    try {
      const tradesJson = await AsyncStorage.getItem(this.TRADES_KEY);
      if (tradesJson) {
        const trades = JSON.parse(tradesJson);
        console.log('TradeService: Loaded trades:', trades.length);
        return trades.sort((a: Trade, b: Trade) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
      }
      return [];
    } catch (error) {
      console.error('TradeService: Error loading trades:', error);
      return [];
    }
  }

  async saveTrade(trade: Trade): Promise<void> {
    try {
      const trades = await this.getAllTrades();
      const existingIndex = trades.findIndex(t => t.id === trade.id);
      
      if (existingIndex >= 0) {
        trades[existingIndex] = trade;
      } else {
        trades.push(trade);
      }
      
      await AsyncStorage.setItem(this.TRADES_KEY, JSON.stringify(trades));
      console.log('TradeService: Trade saved:', trade.id);
    } catch (error) {
      console.error('TradeService: Error saving trade:', error);
      throw error;
    }
  }

  async deleteTrade(tradeId: string): Promise<void> {
    try {
      const trades = await this.getAllTrades();
      const filteredTrades = trades.filter(t => t.id !== tradeId);
      await AsyncStorage.setItem(this.TRADES_KEY, JSON.stringify(filteredTrades));
      console.log('TradeService: Trade deleted:', tradeId);
    } catch (error) {
      console.error('TradeService: Error deleting trade:', error);
      throw error;
    }
  }

  async getTradeById(tradeId: string): Promise<Trade | null> {
    try {
      const trades = await this.getAllTrades();
      return trades.find(t => t.id === tradeId) || null;
    } catch (error) {
      console.error('TradeService: Error getting trade by ID:', error);
      return null;
    }
  }

  // Statistics Calculation
  async getStats(): Promise<TradingStats> {
    try {
      const trades = await this.getAllTrades();
      const closedTrades = trades.filter(t => t.status === 'CLOSED' && t.profit !== undefined);
      
      if (closedTrades.length === 0) {
        return {
          totalTrades: trades.length,
          winRate: 0,
          totalProfit: 0,
          averageProfit: 0,
          winningTrades: 0,
          losingTrades: 0,
          largestWin: 0,
          largestLoss: 0,
        };
      }

      const profits = closedTrades.map(t => t.profit!);
      const winningTrades = profits.filter(p => p > 0).length;
      const losingTrades = profits.filter(p => p < 0).length;
      const totalProfit = profits.reduce((sum, p) => sum + p, 0);
      const winRate = (winningTrades / closedTrades.length) * 100;
      const averageProfit = totalProfit / closedTrades.length;
      const largestWin = Math.max(...profits, 0);
      const largestLoss = Math.min(...profits, 0);

      const stats: TradingStats = {
        totalTrades: trades.length,
        winRate,
        totalProfit,
        averageProfit,
        winningTrades,
        losingTrades,
        largestWin,
        largestLoss,
      };

      console.log('TradeService: Calculated stats:', stats);
      return stats;
    } catch (error) {
      console.error('TradeService: Error calculating stats:', error);
      return {
        totalTrades: 0,
        winRate: 0,
        totalProfit: 0,
        averageProfit: 0,
        winningTrades: 0,
        losingTrades: 0,
        largestWin: 0,
        largestLoss: 0,
      };
    }
  }

  // Demo Data Generation
  async generateDemoData(): Promise<void> {
    console.log('TradeService: Generating demo data...');
    
    const demoTrades: Trade[] = [
      {
        id: '1',
        symbol: 'EURUSD',
        type: 'BUY',
        entryPrice: 1.0850,
        exitPrice: 1.0920,
        volume: 1.0,
        profit: 700,
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        status: 'CLOSED',
        notes: 'Strong bullish momentum after ECB announcement',
        stopLoss: 1.0800,
        takeProfit: 1.0950,
      },
      {
        id: '2',
        symbol: 'GBPUSD',
        type: 'SELL',
        entryPrice: 1.2650,
        exitPrice: 1.2580,
        volume: 0.5,
        profit: 350,
        timestamp: new Date(Date.now() - 172800000).toISOString(),
        status: 'CLOSED',
        notes: 'Brexit concerns driving GBP weakness',
        stopLoss: 1.2700,
        takeProfit: 1.2550,
      },
      {
        id: '3',
        symbol: 'USDJPY',
        type: 'BUY',
        entryPrice: 148.50,
        volume: 0.8,
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        status: 'OPEN',
        notes: 'Waiting for BoJ intervention signals',
        stopLoss: 147.80,
        takeProfit: 149.50,
      },
    ];

    for (const trade of demoTrades) {
      await this.saveTrade(trade);
    }
    
    console.log('TradeService: Demo data generated');
  }
}

export const TradeService = new TradeServiceClass();