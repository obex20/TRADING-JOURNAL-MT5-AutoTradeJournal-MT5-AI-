import { Text, View, ScrollView, RefreshControl } from 'react-native';
import { router } from 'expo-router';
import { useState, useEffect } from 'react';
import Button from '../components/Button';
import { commonStyles, buttonStyles, colors } from '../styles/commonStyles';
import Icon from '../components/Icon';
import TradingStats from '../components/TradingStats';
import TradeList from '../components/TradeList';
import MT5Connection from '../components/MT5Connection';
import { TradeService } from '../services/TradeService';

export default function TradingJournalScreen() {
  const [isConnected, setIsConnected] = useState(false);
  const [trades, setTrades] = useState([]);
  const [stats, setStats] = useState({
    totalTrades: 0,
    winRate: 0,
    totalProfit: 0,
    averageProfit: 0,
  });
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadTrades();
    checkMT5Connection();
  }, []);

  const loadTrades = async () => {
    console.log('Loading trades...');
    try {
      const tradesData = await TradeService.getAllTrades();
      const statsData = await TradeService.getStats();
      setTrades(tradesData);
      setStats(statsData);
      console.log('Trades loaded:', tradesData.length);
    } catch (error) {
      console.error('Error loading trades:', error);
    }
  };

  const checkMT5Connection = async () => {
    console.log('Checking MT5 connection...');
    try {
      const connected = await TradeService.checkConnection();
      setIsConnected(connected);
      console.log('MT5 connection status:', connected);
    } catch (error) {
      console.error('Error checking MT5 connection:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTrades();
    await checkMT5Connection();
    setRefreshing(false);
  };

  const handleAddTrade = () => {
    console.log('Navigate to add trade screen');
    router.push('/add-trade');
  };

  const handleSettings = () => {
    console.log('Navigate to settings screen');
    router.push('/settings');
  };

  return (
    <View style={commonStyles.container}>
      <ScrollView
        style={commonStyles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Header */}
        <View style={[commonStyles.section, { paddingTop: 20 }]}>
          <View style={commonStyles.row}>
            <View>
              <Text style={commonStyles.title}>Trading Journal</Text>
              <Text style={commonStyles.textSecondary}>
                AI-Powered Trade Analysis
              </Text>
            </View>
            <Button
              text=""
              onPress={handleSettings}
              style={{
                backgroundColor: colors.backgroundAlt,
                width: 44,
                height: 44,
                borderRadius: 22,
                padding: 0,
              }}
              textStyle={{ fontSize: 0 }}
            >
              <Icon name="settings-outline" size={24} />
            </Button>
          </View>
        </View>

        {/* MT5 Connection Status */}
        <View style={commonStyles.section}>
          <MT5Connection 
            isConnected={isConnected} 
            onConnectionChange={setIsConnected}
          />
        </View>

        {/* Trading Statistics */}
        <View style={commonStyles.section}>
          <TradingStats stats={stats} />
        </View>

        {/* Quick Actions */}
        <View style={commonStyles.section}>
          <Text style={commonStyles.subtitle}>Quick Actions</Text>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Button
              text="Add Trade"
              onPress={handleAddTrade}
              style={[buttonStyles.primary, { flex: 1 }]}
            />
            <Button
              text="Voice Note"
              onPress={() => router.push('/voice-note')}
              style={[buttonStyles.secondary, { flex: 1 }]}
            />
          </View>
        </View>

        {/* Recent Trades */}
        <View style={commonStyles.section}>
          <TradeList trades={trades} onTradeUpdate={loadTrades} />
        </View>
      </ScrollView>
    </View>
  );
}