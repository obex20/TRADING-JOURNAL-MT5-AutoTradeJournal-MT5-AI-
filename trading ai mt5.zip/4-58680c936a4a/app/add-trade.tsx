import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { commonStyles, colors } from '../styles/commonStyles';
import Button from '../components/Button';
import Icon from '../components/Icon';
import { TradeService, Trade } from '../services/TradeService';

export default function AddTradeScreen() {
  const [symbol, setSymbol] = useState('');
  const [type, setType] = useState<'BUY' | 'SELL'>('BUY');
  const [entryPrice, setEntryPrice] = useState('');
  const [volume, setVolume] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [takeProfit, setTakeProfit] = useState('');
  const [notes, setNotes] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSave = async () => {
    console.log('Saving new trade...');
    
    if (!symbol || !entryPrice || !volume) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    setIsLoading(true);

    try {
      const newTrade: Trade = {
        id: Date.now().toString(),
        symbol: symbol.toUpperCase(),
        type,
        entryPrice: parseFloat(entryPrice),
        volume: parseFloat(volume),
        timestamp: new Date().toISOString(),
        status: 'OPEN',
        notes: notes || undefined,
        stopLoss: stopLoss ? parseFloat(stopLoss) : undefined,
        takeProfit: takeProfit ? parseFloat(takeProfit) : undefined,
      };

      await TradeService.saveTrade(newTrade);
      
      Alert.alert(
        'Success',
        'Trade added successfully',
        [
          {
            text: 'OK',
            onPress: () => router.back(),
          },
        ]
      );
    } catch (error) {
      console.error('Error saving trade:', error);
      Alert.alert('Error', 'Failed to save trade');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={commonStyles.container}>
      <ScrollView style={commonStyles.content}>
        {/* Header */}
        <View style={[commonStyles.section, { paddingTop: 20 }]}>
          <View style={commonStyles.row}>
            <TouchableOpacity
              onPress={() => router.back()}
              style={{
                backgroundColor: colors.backgroundAlt,
                width: 44,
                height: 44,
                borderRadius: 22,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="arrow-back-outline" size={24} />
            </TouchableOpacity>
            <Text style={[commonStyles.title, { flex: 1, textAlign: 'center' }]}>
              Add Trade
            </Text>
            <View style={{ width: 44 }} />
          </View>
        </View>

        {/* Trade Type Selection */}
        <View style={commonStyles.section}>
          <Text style={[commonStyles.text, { marginBottom: 12, fontWeight: '600' }]}>
            Trade Type
          </Text>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <TouchableOpacity
              style={[
                {
                  flex: 1,
                  padding: 16,
                  borderRadius: 8,
                  borderWidth: 2,
                  alignItems: 'center',
                },
                type === 'BUY'
                  ? { backgroundColor: colors.success + '20', borderColor: colors.success }
                  : { backgroundColor: colors.backgroundAlt, borderColor: colors.border },
              ]}
              onPress={() => setType('BUY')}
            >
              <Text
                style={[
                  commonStyles.text,
                  {
                    fontWeight: '600',
                    color: type === 'BUY' ? colors.success : colors.textSecondary,
                  },
                ]}
              >
                BUY
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                {
                  flex: 1,
                  padding: 16,
                  borderRadius: 8,
                  borderWidth: 2,
                  alignItems: 'center',
                },
                type === 'SELL'
                  ? { backgroundColor: colors.danger + '20', borderColor: colors.danger }
                  : { backgroundColor: colors.backgroundAlt, borderColor: colors.border },
              ]}
              onPress={() => setType('SELL')}
            >
              <Text
                style={[
                  commonStyles.text,
                  {
                    fontWeight: '600',
                    color: type === 'SELL' ? colors.danger : colors.textSecondary,
                  },
                ]}
              >
                SELL
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Trade Details */}
        <View style={commonStyles.section}>
          <Text style={[commonStyles.text, { marginBottom: 12, fontWeight: '600' }]}>
            Trade Details
          </Text>
          
          <View style={{ gap: 16 }}>
            <View>
              <Text style={[commonStyles.textSecondary, { marginBottom: 4 }]}>
                Symbol *
              </Text>
              <TextInput
                style={commonStyles.input}
                value={symbol}
                onChangeText={setSymbol}
                placeholder="e.g., EURUSD"
                autoCapitalize="characters"
              />
            </View>

            <View>
              <Text style={[commonStyles.textSecondary, { marginBottom: 4 }]}>
                Entry Price *
              </Text>
              <TextInput
                style={commonStyles.input}
                value={entryPrice}
                onChangeText={setEntryPrice}
                placeholder="0.00000"
                keyboardType="decimal-pad"
              />
            </View>

            <View>
              <Text style={[commonStyles.textSecondary, { marginBottom: 4 }]}>
                Volume (Lots) *
              </Text>
              <TextInput
                style={commonStyles.input}
                value={volume}
                onChangeText={setVolume}
                placeholder="1.00"
                keyboardType="decimal-pad"
              />
            </View>

            <View>
              <Text style={[commonStyles.textSecondary, { marginBottom: 4 }]}>
                Stop Loss
              </Text>
              <TextInput
                style={commonStyles.input}
                value={stopLoss}
                onChangeText={setStopLoss}
                placeholder="0.00000"
                keyboardType="decimal-pad"
              />
            </View>

            <View>
              <Text style={[commonStyles.textSecondary, { marginBottom: 4 }]}>
                Take Profit
              </Text>
              <TextInput
                style={commonStyles.input}
                value={takeProfit}
                onChangeText={setTakeProfit}
                placeholder="0.00000"
                keyboardType="decimal-pad"
              />
            </View>

            <View>
              <Text style={[commonStyles.textSecondary, { marginBottom: 4 }]}>
                Notes
              </Text>
              <TextInput
                style={[commonStyles.input, { height: 80, textAlignVertical: 'top' }]}
                value={notes}
                onChangeText={setNotes}
                placeholder="Add your trading notes..."
                multiline
              />
            </View>
          </View>
        </View>

        {/* Save Button */}
        <View style={[commonStyles.section, { paddingBottom: 40 }]}>
          <Button
            text={isLoading ? 'Saving...' : 'Save Trade'}
            onPress={handleSave}
            style={{
              backgroundColor: colors.primary,
              opacity: isLoading ? 0.6 : 1,
            }}
          />
        </View>
      </ScrollView>
    </View>
  );
}