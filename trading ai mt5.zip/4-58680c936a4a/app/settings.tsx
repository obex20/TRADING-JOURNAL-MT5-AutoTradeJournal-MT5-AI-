import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { commonStyles, colors } from '../styles/commonStyles';
import Button from '../components/Button';
import Icon from '../components/Icon';
import { TradeService } from '../services/TradeService';

export default function SettingsScreen() {
  const [autoSync, setAutoSync] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [voiceNotes, setVoiceNotes] = useState(true);
  const [aiAnalysis, setAiAnalysis] = useState(true);

  const handleGenerateDemoData = async () => {
    Alert.alert(
      'Generate Demo Data',
      'This will add sample trades to your journal. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Generate',
          onPress: async () => {
            console.log('Generating demo data...');
            await TradeService.generateDemoData();
            Alert.alert('Success', 'Demo data generated successfully');
          },
        },
      ]
    );
  };

  const handleExportData = () => {
    Alert.alert(
      'Export Data',
      'Export your trading data to CSV format',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Export',
          onPress: () => {
            console.log('Exporting data...');
            Alert.alert('Success', 'Data exported successfully');
          },
        },
      ]
    );
  };

  const handleClearData = () => {
    Alert.alert(
      'Clear All Data',
      'This will permanently delete all your trades and settings. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: () => {
            console.log('Clearing all data...');
            Alert.alert('Success', 'All data cleared');
          },
        },
      ]
    );
  };

  const SettingItem = ({
    title,
    subtitle,
    value,
    onValueChange,
    type = 'switch',
    onPress,
    icon,
    color = colors.primary,
  }: {
    title: string;
    subtitle?: string;
    value?: boolean;
    onValueChange?: (value: boolean) => void;
    type?: 'switch' | 'button';
    onPress?: () => void;
    icon: string;
    color?: string;
  }) => (
    <TouchableOpacity
      style={[
        commonStyles.card,
        { flexDirection: 'row', alignItems: 'center' },
      ]}
      onPress={onPress}
      disabled={type === 'switch'}
    >
      <View
        style={{
          backgroundColor: `${color}20`,
          borderRadius: 8,
          padding: 8,
          marginRight: 16,
        }}
      >
        <Icon name={icon as any} size={24} style={{ color }} />
      </View>
      
      <View style={{ flex: 1 }}>
        <Text style={[commonStyles.text, { fontWeight: '600' }]}>
          {title}
        </Text>
        {subtitle && (
          <Text style={commonStyles.textSecondary}>{subtitle}</Text>
        )}
      </View>

      {type === 'switch' && (
        <Switch
          value={value}
          onValueChange={onValueChange}
          trackColor={{ false: colors.border, true: `${color}40` }}
          thumbColor={value ? color : colors.textSecondary}
        />
      )}

      {type === 'button' && (
        <Icon
          name="chevron-forward-outline"
          size={20}
          style={{ color: colors.textSecondary }}
        />
      )}
    </TouchableOpacity>
  );

  return (
    <View style={commonStyles.container}>
      <ScrollView style={commonStyles.content}>
        {/* Header */}
        <View style={[commonStyles.section, { paddingTop: 20 }]}>
          <View style={commonStyles.row}>
            <TouchableOpacity
              onPress={() => router.back()}
              style={{
                backgroundColor: colors.backgroundAlt,
                width: 44,
                height: 44,
                borderRadius: 22,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="arrow-back-outline" size={24} />
            </TouchableOpacity>
            <Text style={[commonStyles.title, { flex: 1, textAlign: 'center' }]}>
              Settings
            </Text>
            <View style={{ width: 44 }} />
          </View>
        </View>

        {/* MT5 Integration */}
        <View style={commonStyles.section}>
          <Text style={commonStyles.subtitle}>MT5 Integration</Text>
          
          <SettingItem
            title="Auto Sync"
            subtitle="Automatically sync trades from MT5"
            icon="sync-outline"
            value={autoSync}
            onValueChange={setAutoSync}
          />
          
          <SettingItem
            title="MT5 Connection"
            subtitle="Configure MT5 server settings"
            icon="server-outline"
            type="button"
            onPress={() => Alert.alert('Info', 'MT5 connection settings')}
          />
        </View>

        {/* Notifications */}
        <View style={commonStyles.section}>
          <Text style={commonStyles.subtitle}>Notifications</Text>
          
          <SettingItem
            title="Trade Alerts"
            subtitle="Get notified when trades are executed"
            icon="notifications-outline"
            value={notifications}
            onValueChange={setNotifications}
            color={colors.warning}
          />
        </View>

        {/* AI Features */}
        <View style={commonStyles.section}>
          <Text style={commonStyles.subtitle}>AI Features</Text>
          
          <SettingItem
            title="Voice Notes"
            subtitle="Enable voice-to-text for trade notes"
            icon="mic-outline"
            value={voiceNotes}
            onValueChange={setVoiceNotes}
            color={colors.secondary}
          />
          
          <SettingItem
            title="AI Analysis"
            subtitle="Get AI insights on your trades"
            icon="analytics-outline"
            value={aiAnalysis}
            onValueChange={setAiAnalysis}
            color={colors.secondary}
          />
        </View>

        {/* Data Management */}
        <View style={commonStyles.section}>
          <Text style={commonStyles.subtitle}>Data Management</Text>
          
          <SettingItem
            title="Generate Demo Data"
            subtitle="Add sample trades for testing"
            icon="add-circle-outline"
            type="button"
            onPress={handleGenerateDemoData}
            color={colors.success}
          />
          
          <SettingItem
            title="Export Data"
            subtitle="Export trades to CSV"
            icon="download-outline"
            type="button"
            onPress={handleExportData}
            color={colors.primary}
          />
          
          <SettingItem
            title="Clear All Data"
            subtitle="Delete all trades and settings"
            icon="trash-outline"
            type="button"
            onPress={handleClearData}
            color={colors.danger}
          />
        </View>

        {/* App Info */}
        <View style={[commonStyles.section, { paddingBottom: 40 }]}>
          <Text style={commonStyles.subtitle}>About</Text>
          
          <View style={commonStyles.card}>
            <Text style={[commonStyles.text, { fontWeight: '600', marginBottom: 8 }]}>
              AI Trading Journal
            </Text>
            <Text style={commonStyles.textSecondary}>
              Version 1.0.0
            </Text>
            <Text style={[commonStyles.textSecondary, { marginTop: 8 }]}>
              Seamlessly integrate with MetaTrader 5 for automated trade logging and AI-powered analysis.
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}