import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Alert,
  TextInput,
} from 'react-native';
import { router } from 'expo-router';
import { commonStyles, colors } from '../styles/commonStyles';
import Button from '../components/Button';
import Icon from '../components/Icon';
import * as Speech from 'expo-speech';

export default function VoiceNoteScreen() {
  const [isRecording, setIsRecording] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [analysis, setAnalysis] = useState('');

  const startRecording = async () => {
    console.log('Starting voice recording...');
    setIsRecording(true);
    
    // Simulate voice recording
    setTimeout(() => {
      setIsRecording(false);
      setTranscription(
        "Today's EURUSD trade was excellent. I entered at 1.0850 after seeing strong bullish momentum following the ECB announcement. The trade hit my take profit at 1.0920 for a nice 70 pip gain. I should continue watching for similar setups when central bank news creates momentum."
      );
    }, 3000);
  };

  const stopRecording = () => {
    console.log('Stopping voice recording...');
    setIsRecording(false);
  };

  const analyzeTranscription = async () => {
    if (!transcription.trim()) {
      Alert.alert('Error', 'No transcription to analyze');
      return;
    }

    console.log('Analyzing transcription...');
    setIsProcessing(true);

    // Simulate AI analysis
    setTimeout(() => {
      const aiAnalysis = `
**AI Analysis Summary:**

**Trade Identified:**
- Symbol: EURUSD
- Entry: 1.0850
- Exit: 1.0920
- Profit: +70 pips
- Trigger: ECB announcement

**Key Insights:**
- Strong fundamental analysis approach
- Good risk management with defined targets
- Pattern recognition: Central bank news momentum
- Positive outcome reinforces strategy

**Recommendations:**
- Continue monitoring ECB announcements
- Consider similar setups with other central banks
- Document specific momentum indicators used
- Track success rate of news-based trades

**Sentiment:** Positive ✅
**Confidence Level:** High
**Strategy Type:** Fundamental + Technical
      `;
      
      setAnalysis(aiAnalysis);
      setIsProcessing(false);
    }, 2000);
  };

  const saveNote = async () => {
    if (!transcription.trim()) {
      Alert.alert('Error', 'No content to save');
      return;
    }

    console.log('Saving voice note...');
    
    // Here you would save the note to your database
    Alert.alert(
      'Success',
      'Voice note saved successfully',
      [
        {
          text: 'OK',
          onPress: () => router.back(),
        },
      ]
    );
  };

  const speakText = (text: string) => {
    Speech.speak(text, {
      language: 'en-US',
      pitch: 1.0,
      rate: 0.8,
    });
  };

  return (
    <View style={commonStyles.container}>
      <ScrollView style={commonStyles.content}>
        {/* Header */}
        <View style={[commonStyles.section, { paddingTop: 20 }]}>
          <View style={commonStyles.row}>
            <TouchableOpacity
              onPress={() => router.back()}
              style={{
                backgroundColor: colors.backgroundAlt,
                width: 44,
                height: 44,
                borderRadius: 22,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Icon name="arrow-back-outline" size={24} />
            </TouchableOpacity>
            <Text style={[commonStyles.title, { flex: 1, textAlign: 'center' }]}>
              Voice Note
            </Text>
            <View style={{ width: 44 }} />
          </View>
        </View>

        {/* Recording Section */}
        <View style={commonStyles.section}>
          <Text style={[commonStyles.subtitle, { textAlign: 'center' }]}>
            Record Your Trading Thoughts
          </Text>
          
          <View style={{ alignItems: 'center', marginVertical: 32 }}>
            <TouchableOpacity
              style={{
                width: 120,
                height: 120,
                borderRadius: 60,
                backgroundColor: isRecording ? colors.danger : colors.primary,
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 16,
              }}
              onPress={isRecording ? stopRecording : startRecording}
            >
              <Icon
                name={isRecording ? 'stop' : 'mic'}
                size={48}
                style={{ color: colors.background }}
              />
            </TouchableOpacity>
            
            <Text style={[commonStyles.text, { textAlign: 'center' }]}>
              {isRecording ? 'Recording... Tap to stop' : 'Tap to start recording'}
            </Text>
            
            {isRecording && (
              <View style={{ marginTop: 16 }}>
                <Text style={[commonStyles.textSecondary, { textAlign: 'center' }]}>
                  🔴 Recording in progress...
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Transcription */}
        {transcription && (
          <View style={commonStyles.section}>
            <View style={commonStyles.row}>
              <Text style={commonStyles.subtitle}>Transcription</Text>
              <TouchableOpacity onPress={() => speakText(transcription)}>
                <Icon name="volume-high-outline" size={24} style={{ color: colors.primary }} />
              </TouchableOpacity>
            </View>
            
            <View style={commonStyles.card}>
              <TextInput
                style={[
                  commonStyles.text,
                  { minHeight: 100, textAlignVertical: 'top' },
                ]}
                value={transcription}
                onChangeText={setTranscription}
                multiline
                placeholder="Your transcription will appear here..."
              />
            </View>

            <Button
              text={isProcessing ? 'Analyzing...' : 'Analyze with AI'}
              onPress={analyzeTranscription}
              style={{
                backgroundColor: colors.secondary,
                marginTop: 12,
                opacity: isProcessing ? 0.6 : 1,
              }}
            />
          </View>
        )}

        {/* AI Analysis */}
        {analysis && (
          <View style={commonStyles.section}>
            <View style={commonStyles.row}>
              <Text style={commonStyles.subtitle}>AI Analysis</Text>
              <TouchableOpacity onPress={() => speakText(analysis)}>
                <Icon name="volume-high-outline" size={24} style={{ color: colors.primary }} />
              </TouchableOpacity>
            </View>
            
            <View style={[commonStyles.card, { backgroundColor: colors.backgroundAlt }]}>
              <Text style={commonStyles.text}>{analysis}</Text>
            </View>
          </View>
        )}

        {/* Save Button */}
        {transcription && (
          <View style={[commonStyles.section, { paddingBottom: 40 }]}>
            <Button
              text="Save Note"
              onPress={saveNote}
              style={{ backgroundColor: colors.success }}
            />
          </View>
        )}
      </ScrollView>
    </View>
  );
}